Warning:
1) Do not delete or modify any of the files or folders in the application folder, unless you know what you are doing.
2) Do not move the .exe file anywhere from the application folder, unless you know what you are doing.
Any of these actions can and likely will lead to malfunctions in the application.

Basic usage:

-Add tasks by clicking on Add Task button. 
You will then be prompted to enter the task information: name, points, start time, end time.
There are six conditions for correct task addition:
1) name must contain at least one symbol. 
2) points must be more than 0.
3) start time must be before end time.
4) hours must be from 0 to 23.
5) minutes must be from 0 to 59.
6) seconds must be from 0 to 59.
If all the conditions are met, pressing Confirm button will add a new task to the task list.
If any of these conditions is not met, pressing Confirm button will not do anything. You will still be prompted to enter correct task information.

-Delete tasks by clicking on red X buttons near tasks.

-Put checks near tasks by clicking blue squares in front of tasks.

-All the tasks are unchecked automatically each day. 
